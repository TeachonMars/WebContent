// Function for init
$('#init').on('click', function (e) {
  e.preventDefault();
  ToM.data.init();
});

// Function for send
$('#send').on('click', function (e) {
  e.preventDefault();
  ToM.data.send();
});

// Functions for time
$('#setTime').on('click', function (e) {
  e.preventDefault();
  var timeField = $('#timeField').get(0).MaterialTextfield;
  ToM.data.set('time', timeField.input_.value);
});

$('#getTime').on('click', function (e) {
  e.preventDefault();
  var timeField = $('#timeField').get(0).MaterialTextfield;
  timeField.change(ToM.data.get('time') || 0);
});

// Functions for points
$('#setPoints').on('click', function (e) {
  e.preventDefault();
  var pointField = $('#pointsField').get(0).MaterialTextfield;
  ToM.data.set('points', pointField.input_.value);
});

$('#getPoints').on('click', function (e) {
  e.preventDefault();
  var pointField = $('#pointsField').get(0).MaterialTextfield;
  pointField.change(ToM.data.get('points') || 0);
});

// Functions for progress
$('#setProgress').on('click', function (e) {
  e.preventDefault();
  var progressSlider = $('#progress').get(0).MaterialSlider;
  ToM.data.set('progress', progressSlider.element_.value);
});

$('#getProgress').on('click', function (e) {
  e.preventDefault();
  var progressSlider = $('#progress').get(0).MaterialSlider;
  progressSlider.change(ToM.data.get('progress') || 0);
  labelMaker(document.getElementById('progress'));
});

// Functions for score
$('#setScore').on('click', function (e) {
  e.preventDefault();
  var scoreSlider = $('#score').get(0).MaterialSlider;
  ToM.data.set('score', scoreSlider.element_.value);
});

$('#getScore').on('click', function (e) {
  e.preventDefault();
  var scoreSlider = $('#score').get(0).MaterialSlider;
  scoreSlider.change(ToM.data.get('score') || 0);
  labelMaker(document.getElementById('score'));
});

// Functions for success
$('#setSuccess').on('click', function (e) {
  e.preventDefault();
  var successSwitch = $('#successSwitch').get(0).MaterialSwitch;
  var value = successSwitch.inputElement_.checked;
  ToM.data.set('success', value);
});

$('#getSuccess').on('click', function (e) {
  e.preventDefault();
  var res = ToM.data.get('success');
  var successSwitch = $('#successSwitch').get(0).MaterialSwitch;
  if (res === true) {
    successSwitch.on();
  } else {
    successSwitch.off();
  }
});

// Place labels over
labelMaker = function (e) {
  var input = e.target || e,
    label = input.parentElement.querySelectorAll('.label')[0] || document.createElement('div'),
    labelInner = label.firstChild || document.createElement('div'),
    parentWidth = input.parentElement.offsetWidth,
    inputWidth = input.offsetWidth,
    labelOffset = (parentWidth - inputWidth) / 2,
    labelPosX = inputWidth * (input.value / 100) + ((100 - input.value) * 14) / 100;

  label.classList.add('label');
  labelInner.innerText = input.value;
  label.appendChild(labelInner);
  label.style.left = labelPosX + 'px';
  input.parentElement.appendChild(label);
};

var progressInput = document.getElementById('progress'),
  scoreInput = document.getElementById('score');

progressInput.addEventListener('input', labelMaker);
scoreInput.addEventListener('input', labelMaker);

window.onload = function () {
  labelMaker(progressInput);
  labelMaker(scoreInput);
};

_.mixin({
  'sortKeysBy': function (obj, comparator) {
    var keys = _.sortBy(_.keys(obj), function (key) {
      return comparator ? comparator(obj[key], key) : key;
    });

    return _.zipObject(keys, _.map(keys, function (key) {
      return obj[key];
    }));
  }
});

function displayEnvVars() {
  var placeholders = ToM.env.getAll();
  placeholders = _.sortKeysBy(placeholders);
  var divElem = document.getElementById("envVars");
  for (var key in placeholders) {
    if (placeholders.hasOwnProperty(key)) {
      var pElem = document.createElement('p'),
        spanElem = document.createElement('span'),
        text = document.createTextNode(key + " : "),
        id = document.createAttribute("id");
      id.value = key;
      spanElem.setAttributeNode(id);
      spanElem.appendChild(document.createTextNode(placeholders[key]));
      pElem.appendChild(text);
      pElem.appendChild(spanElem);
      divElem.appendChild(pElem);
    }
  }
}

function displayParamVars() {
  var placeholders = ToM.params.getAll();
  placeholders = _.sortKeysBy(placeholders);
  var divElem = document.getElementById("paramVars");
  for (var key in placeholders) {
    if (placeholders.hasOwnProperty(key)) {
      var pElem = document.createElement('p'),
        spanElem = document.createElement('span'),
        text = document.createTextNode(key + " : "),
        id = document.createAttribute("id");
      id.value = key;
      spanElem.setAttributeNode(id);
      spanElem.appendChild(document.createTextNode(placeholders[key]));
      pElem.appendChild(text);
      pElem.appendChild(spanElem);
      divElem.appendChild(pElem);
    }
  }
}